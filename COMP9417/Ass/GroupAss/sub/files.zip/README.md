# COMP9417 group Assignment

## Group member

+ Yiyan Yang z5183946
+ Daniel Qian z5183850

## Content

&emsp;Two files are submitted: file.zip and report.pdf
file.zip includes:
+ CNN.py
+ result.csv
+ README.md

## Question and Data could be found here.
https://www.kaggle.com/c/dogs-vs-cats-redux-kernels-edition/overview

## Test result:

PASSED
