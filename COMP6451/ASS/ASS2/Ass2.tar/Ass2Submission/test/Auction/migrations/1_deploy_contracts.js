const Auction = artifacts.require("Auction");
const Registry = artifacts.require("SophisticatedInvestorCertificateAuthorityRegistry");

module.exports = function(deployer) {
//   deployer.deploy(Registry);
//   deployer.deploy(Auction);
};
